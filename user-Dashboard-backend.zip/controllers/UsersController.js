const mongoose = require("mongoose");
const User = require("../models/UsersModel");
const Blacklist = require('../models/BlacklistModel');
const jwt = require('jsonwebtoken');
require('dotenv').config()





const signupUser = async (req, res) => {
  const walletAddress = req.body.walletAddress;
  try {
    const user = await User.findOne({ walletAddress });

    if (user) {
      // check if the token is blacklisted
      const blacklistedToken = await Blacklist.findOne({ token: req.body.token });
      if (blacklistedToken) {
        res.status(401).json({ message: 'Token is blacklisted' });
        return;
      }

      const token = jwt.sign({ userId: user.userId }, process.env.JWT_SECRET, { expiresIn: '1h' });
      res.status(200).json({ message: 'User Exist! jwt session started', user, token });
    } else {
      const newUser = new User({
        userId: req.body.userId,
        walletAddress: req.body.walletAddress,
        token: req.body.token,
      });
      const savedUser = await newUser.save();
      if (savedUser) {
        const token = jwt.sign({ userId: savedUser.userId }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ message: 'User created, token created', savedUser, token });
      } else {
        res.status(201).json({ message: 'No address found please Signup', walletAddress });
      }
    }
  } catch (err) {
    res.status(500).json({ message: 'Error Occured' });
  }
};
const logoutUser = async(req, res)=> {
  // get the JWT token from the request header
  const token = req.headers.authorization.split(' ')[1];
  
  // add the token to a blacklist
  const blacklistedToken = new Blacklist({ token });
  await blacklistedToken.save();
  
  // send a response to the client
  res.json({ message: 'Logout successful' });
};

module.exports = {
  
  signupUser,
  logoutUser
};


